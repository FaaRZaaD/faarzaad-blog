import React from 'react'

import App from '../components/App'

const NotFoundPage = () => (
  <App>
    <h1>پیدا نشد</h1>
    <p>صفحه پیدا نشد</p>
  </App>
)

export default NotFoundPage
